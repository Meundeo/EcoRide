<?php session_start();
    require_once 'connexionBDD.php';


    if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
    }


    if (isset($_GET['id'])) {
        $covoiturage_id = $_GET['id'];
        $user_id = $_SESSION['user']['pseudo'];

    try {

        $pdo->beginTransaction();


        $stmt = $pdo->prepare("DELETE FROM inscription WHERE covoiturage_id = :covoiturage_id AND utilisateur_pseudo = :user_id");
        $stmt->execute([
            ':covoiturage_id' => $covoiturage_id,
            ':user_id' => $user_id
        ]);


        $stmt = $pdo->prepare("UPDATE covoiturage SET nb_place = nb_place + 1 WHERE covoiturage_id = :covoiturage_id");
        $stmt->execute([
            ':covoiturage_id' => $covoiturage_id
        ]);


        $pdo->commit();


        header('Location: ../utilisateur.php');
        exit;

    } catch (PDOException $e) {

        $pdo->rollBack();
        echo "Erreur : " . $e->getMessage();
    }
} else {
    echo "L'ID du covoiturage est manquant.";
}
?>