<?php
    require_once 'connexionBDD.php';


    $sql = "SELECT SUM(credit) AS total_credits FROM utilisateurs WHERE role = 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    $totalCredits = $data['total_credits'];


        echo '<div class="compteur">';
        echo '<h4 style="color: #EBF2FA; margin: auto 20px; text-decoration: underline;">Nombre de crédits gagnés par la plateforme :</h4>' . "<br>";
        echo '<input type="text" style="color: #427AA1; font-size: 30px; text-align: center; margin-bottom: 10px;" value="' . number_format($totalCredits, 0, ',', ' ') . '" readonly>';
        echo '</div>';
?>