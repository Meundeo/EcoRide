<head>
    <link href="/style/styleFooter.css" rel="stylesheet">
</head>

<footer class="container-fluid text-center footer">
    <a class="navbar-brand" href="/index.php">EcoRide</a>
    <div class="row">
        <div class="col-12 col-lg-6">
            <p>contact@ecoride.com</p>
        </div>
        <div class="col-12 col-lg-6">
            <a href="/">Mentions légales</a>
        </div>
    </div>
</footer>