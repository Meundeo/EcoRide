<head>
    <link href="../style/styleBigTitle.css" rel="stylesheet">
</head>

<body>
    <div class="tigre">
        <div class="tigre-content">
            <h1>EcoRide le futur du déplacement</h1><br><br>
            <h4>Une mobilité éco-responsable</h4>
        </div>
    </div>
</body>