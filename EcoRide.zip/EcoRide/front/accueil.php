<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/style/styleIndex.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container mt-5">
        <div class="card mb-4">
            <div class="row g-0 align-items-center flex-row-reverse">
                <div class="col-md-6 d-flex justify-content-center align-items-center">
                    <img src="../images/accueil1.png" class="img-fluid rounded-start" style="width: 75%; margin: 20px;"
                        alt="Image droite">
                </div>
                <div class="col-md-6">
                    <div class="card-body">
                        <h3 class="card-title">Une seule voiture, un impact positif pour tous</h3><br><br>
                        <p class="card-text">Et si une seule voiture pouvait transporter plusieurs personnes ? Notre plateforme de covoiturage écoresponsable vous aide à réduire le nombre de véhicules sur les routes, contribuant ainsi à diminuer la pollution et les embouteillages. En partageant vos trajets, vous maximisez l’utilisation d’un seul véhicule pour plusieurs passagers, tout en réduisant vos dépenses en carburant et en entretien. Ensemble, adoptons un mode de transport plus pratique, économique et respectueux de l’environnement.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="card mb-4">
            <div class="row g-0 align-items-center">
                <div class="col-md-6">
                    <img src="../images/carbon-footprint-6855793_640.jpg" class="img-fluid rounded-start"
                        style="width: 90%; margin: 20px;" alt="Image droite">
                </div>
                <div class="col-md-6">
                    <div class="card-body">
                        <h3 class="card-title">Diminuez votre empreinte carbone en partageant vos trajets</h3><br><br>
                        <p class="card-text">Explorez notre plateforme de covoiturage écoresponsable, pensée pour rassembler les voyageurs désireux de contribuer à la protection de l’environnement. En partageant vos trajets avec d’autres utilisateurs, vous réduisez considérablement votre empreinte carbone. Grâce à notre interface intuitive, trouvez facilement des trajets adaptés à vos besoins, tout en rejoignant une communauté de conducteurs et passagers engagés pour un futur plus durable.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

     
    <article>

        <div class="container mt-5">
            <div class="card mb-4">
            <div class="container p-4">
                <div class="row row-cols-2 align-items-center">
                    <div class="col">
                        <img class="w-100 rounded" src="../images/pexels-kampus-7967388.jpg"/>
                    </div>
                    <div class="col">
                    <h3 class="card-title">Faites de nouvelles rencontres ! </h3><br><br>
                        <p class="text-justify">
                        Ecoride est l’application de covoiturage idéale pour allier écologie, économies et rencontres enrichissantes. Grâce à son algorithme intelligent, elle met en relation des passagers et conducteurs partageant les mêmes trajets et centres d’intérêt. Que ce soit pour un trajet quotidien ou un voyage improvisé, Ecoride facilite la mise en contact et garantit une expérience conviviale et sécurisée. Son système de messagerie intégré permet d’échanger avant le départ, et son programme de fidélité récompense les utilisateurs réguliers. En favorisant le partage de trajets, Ecoride réduit l’empreinte carbone tout en créant du lien social. Essayez Ecoride et transformez vos déplacements en moments de partage !
                        </p>
                    </div>
                </div>
            </div> 
            </div>
        </div>
       
    </article>
        
        <article>

        <div class="container mt-5">
            <div class="card mb-4">
            <div class="container p-4">
                <div class="row row-cols-2 align-items-center">
                    <div class="col">
                    <h3 class="card-title">Faites des économies !</h3><br><br>
                        <p class="text-justify">
                        Avec Ecoride, faire des économies tout en voyageant devient un jeu d’enfant ! En partageant les frais de carburant et de péage, conducteurs et passagers réduisent considérablement leurs dépenses. Fini les trajets coûteux en solo : grâce à Ecoride, chaque place libre dans une voiture devient une opportunité d’économiser. L’application propose un système de paiement sécurisé et transparent, garantissant une répartition équitable des coûts. De plus, en optimisant les trajets, elle permet de réduire l’usure du véhicule et les dépenses liées à l’entretien. Adoptez Ecoride et profitez d’un transport plus économique, tout en contribuant à une mobilité plus responsable !                        </p>
                    </div>
                    <div class="col">
                        <img class="w-100 rounded" src="../images/pexels-karolina-grabowska-4386292.jpg"/>
                    </div>
                </div>
            </div>
            </div>
        </div>
        </article>
        
        <article>

        <div class="container mt-5">
            <div class="card mb-4">
            <div class="container p-4">
                <div class="row row-cols-2 align-items-center">
                    <div class="col">
                        <img class="w-100 rounded" src="../images/pexels-koolshooters-8973867.jpg"/>
                    </div>
                    <div class="col">
                    <h3 class="card-title">Découvrez le monde !</h3><br><br>
                        <p class="text-justify">
                        Avec Ecoride, découvrez le monde tout en préservant la planète ! Cette application de covoiturage vous permet de voyager de manière plus écologique en réduisant votre empreinte carbone. En partageant un véhicule, vous diminuez le nombre de voitures sur la route, limitant ainsi les émissions de CO₂ et la pollution. Que ce soit pour une escapade spontanée ou un long voyage, Ecoride vous offre une alternative durable aux transports individuels. En plus de protéger l’environnement, vous faites des rencontres enrichissantes et profitez d’un trajet plus convivial. Adoptez une nouvelle façon de voyager : plus verte, plus économique et plus humaine avec Ecoride !                        </p>
                    </div>
                </div>
            </div>
            </div>
            </div>
        </article>
        

</body>